package gr.hua.dit.it22023_it22121.abstract_syntax_tree.abstraction;

public abstract class Condition extends Expression {
}