# Assignment for Compilers Course DIT HUA

## Authors:

- Nikos Gournakis
- Arvi Hoxha

### Building the compiler

``mvn clean package``

### Building compiler and run tests

#### this is currently not working

``python test_runner.py``

### Compiling and executing file

``java -jar target/compiler-0.0.2.jar < file.alan``